# Pastebin Clone - SPEC.md

## Concept & Vision

A sleek, developer-focused pastebin clone that feels like a premium tool rather than a bare-bones text storage. Dark theme with monospace aesthetics evokes the terminal/IDE environment where developers live. The interface is minimal but powerful — every element serves a purpose, with subtle animations that make interactions feel snappy and intentional.

## Design Language

### Aesthetic Direction
Dark mode terminal aesthetic with a hint of warmth. Think VS Code's dark theme meets a hacker's personal tool. Clean lines, generous spacing, and syntax-highlighted code as the centerpiece.

### Color Palette
- **Background**: `#0a0a0f` (deep charcoal-black)
- **Surface**: `#12121a` (slightly lighter for cards/panels)
- **Border**: `#2a2a3a` (subtle separation)
- **Text Primary**: `#e4e4e7` (warm white)
- **Text Secondary**: `#71717a` (muted gray)
- **Accent**: `#22d3ee` (cyan glow — reminiscent of terminal cursors)
- **Accent Hover**: `#06b6d4` (darker cyan)
- **Danger**: `#ef4444` (red for destructive actions)
- **Success**: `#10b981` (green for confirmations)

### Typography
- **Headings**: JetBrains Mono (bold, modern monospace)
- **Body**: Inter (readable sans-serif for descriptions)
- **Code**: JetBrains Mono (matching the aesthetic)

### Spatial System
- Base unit: 4px
- Component padding: 12px-16px
- Section gaps: 32px-48px
- Max content width: 800px for readability

### Motion Philosophy
- Micro-interactions: 150ms ease-out for hover states
- Page transitions: fade-in 200ms
- Button press: subtle scale(0.98) feedback
- Toast notifications: slide-in from top, 3s duration

### Visual Assets
- Lucide icons (consistent, minimal line icons)
- No images needed — pure UI
- Subtle gradient accents on key elements

## Layout & Structure

### Page Architecture

**Homepage (/)**
- Hero section with app name and tagline
- "New Paste" prominent CTA
- Recent pastes grid (last 10)
- Minimal footer with tech stack info

**View Paste (/[slug])**
- Full-width code display with syntax highlighting
- Header: title, language badge, copy button
- Metadata bar: created date, expiry status
- Raw view link
- Navigation back home

**Create Paste (/new)**
- Clean form: title, description, language dropdown, content textarea, expiry picker
- Preview toggle (stretch goal)
- Submit with loading state

**Admin Panel (/admin)**
- Password gate (simple, elegant)
- Dashboard with paste table
- Each row: title, slug, created date, language, edit/delete buttons
- Modal or inline edit capability
- Logout button

### Responsive Strategy
- Mobile-first
- Single column on mobile, comfortable width on desktop
- Code blocks scroll horizontally, never wrap

## Features & Interactions

### Paste Creation
- **Fields**: title (optional, default "Untitled"), description (optional), content (required), language (dropdown), expiry (optional date picker)
- **Slug generation**: 8-character nanoid, URL-safe
- **On submit**: validate content not empty → create → redirect to view page
- **Error handling**: show inline error message, preserve form data

### Paste Viewing
- **Syntax highlighting**: highlight.js with auto language detection fallback
- **Copy button**: copies content to clipboard, shows "Copied!" toast
- **Expired paste**: show expiration message, hide content
- **Raw view**: `/[slug]/raw` returns `Content-Type: text/plain`

### Admin Authentication
- Single password from `ADMIN_SECRET` env var
- Store auth state in httpOnly cookie (JWT or session)
- 24-hour expiry on session
- Redirect to login if not authenticated

### Admin Operations
- **List**: fetch all pastes, show in table
- **Delete**: confirm modal → delete → refresh list
- **Edit**: open edit modal with pre-filled form → save → refresh
- **Create from admin**: same form as public /new

### Edge Cases
- **Slug collision**: extremely unlikely with nanoid, but regenerate on conflict
- **Empty content**: prevent submission, show error
- **Invalid slug**: 404 page with home link
- **Expired viewing**: show message, no content

## Component Inventory

### Button
- **Variants**: primary (cyan bg), secondary (border only), danger (red)
- **States**: default, hover (lighten), active (scale down), disabled (opacity 0.5), loading (spinner)

### Input / Textarea
- Dark background (`#12121a`), light border
- Focus: cyan border glow
- Error: red border
- Placeholder: muted text

### Select (Language Picker)
- Styled dropdown matching inputs
- Search/filter for many languages
- Common languages at top

### Code Block
- Monospace, syntax highlighted
- Horizontal scroll for long lines
- Line numbers optional (stretch)

### Toast Notification
- Fixed top-right position
- Slide in, auto-dismiss 3s
- Variants: success (green), error (red), info (cyan)

### Modal
- Centered overlay with backdrop blur
- Close on escape or backdrop click
- Focus trap for accessibility

### Paste Card (Homepage)
- Title, language badge, created date
- Hover: subtle lift, border glow
- Click: navigate to view

### Admin Table
- Striped rows for readability
- Actions column with icon buttons
- Responsive: horizontal scroll or card view on mobile

## Technical Approach

### Framework & Runtime
- **Next.js 14** with App Router
- **React 18** with Server Components where beneficial
- **TypeScript** for type safety

### Styling
- **Tailwind CSS** for utility classes
- Custom theme extending Tailwind defaults
- Dark mode only (no toggle needed)

### Database
- **SQLite** via `better-sqlite3` for simplicity and portability
- File-based storage in project directory
- Schema:
  ```sql
  CREATE TABLE pastes (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    title TEXT DEFAULT 'Untitled',
    description TEXT,
    content TEXT NOT NULL,
    language TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
  );
  ```

### API Design
- **POST /api/pastes** — Create paste (public)
- **GET /api/pastes** — List all (admin only)
- **GET /api/pastes/[slug]** — Get single paste (public)
- **PUT /api/pastes/[slug]** — Update paste (admin only)
- **DELETE /api/pastes/[slug]** — Delete paste (admin only)
- **POST /api/admin/login** — Authenticate admin
- **POST /api/admin/logout** — End session

### Authentication
- Password comparison with `ADMIN_SECRET`
- JWT token in httpOnly cookie
- Middleware checks protected routes

### Key Libraries
- `nanoid` — slug generation
- `highlight.js` — syntax highlighting (client-side)
- `better-sqlite3` — database
- `jose` — JWT handling

### Environment Variables
- `ADMIN_SECRET` — admin password
- `DATABASE_URL` — path to SQLite file (default: `./data/pastebin.db`)

## File Structure
```
/app
  /page.tsx                 # Homepage
  /new/page.tsx             # Create paste form
  /[slug]/page.tsx          # View paste
  /[slug]/raw/route.ts      # Raw text endpoint
  /admin/page.tsx           # Admin dashboard
  /api/pastes/route.ts      # CRUD API
  /api/pastes/[slug]/route.ts
  /api/admin/login/route.ts
  /api/admin/logout/route.ts
  /layout.tsx               # Root layout with providers
  /globals.css              # Tailwind imports + custom styles
/components
  /ui/Button.tsx
  /ui/Input.tsx
  /ui/Modal.tsx
  /ui/Toast.tsx
  /PasteCard.tsx
  /CodeBlock.tsx
  /LanguageSelect.tsx
/lib
  /db.ts                    # Database setup + queries
  /auth.ts                  # Auth utilities
  /utils.ts                 # Helpers (slug gen, etc.)
```