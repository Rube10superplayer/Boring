'use client'

import React, { useEffect, useRef } from 'react'
import hljs from 'highlight.js'

interface CodeBlockProps {
  code: string
  language: string | null
}

export function CodeBlock({ code, language }: CodeBlockProps) {
  const codeRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (codeRef.current) {
      if (language && hljs.getLanguage(language)) {
        codeRef.current.className = `hljs language-${language}`
        codeRef.current.textContent = code
        hljs.highlightElement(codeRef.current)
      } else {
        codeRef.current.textContent = code
        hljs.highlightElement(codeRef.current)
      }
    }
  }, [code, language])

  return (
    <div className="relative group">
      <pre className="bg-surface border border-border rounded-lg p-4 overflow-x-auto">
        <code ref={codeRef} className="font-mono text-sm leading-relaxed">
          {code}
        </code>
      </pre>
    </div>
  )
}