import Link from 'next/link'
import { formatRelativeDate, truncate } from '@/lib/utils'

interface PasteCardProps {
  slug: string
  title: string
  language: string | null
  created_at: string
  content: string
}

export function PasteCard({ slug, title, language, created_at, content }: PasteCardProps) {
  return (
    <Link
      href={`/${slug}`}
      className="block bg-surface border border-border rounded-xl p-5 hover:border-accent/50 transition-all duration-150 group"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h3 className="font-mono font-semibold text-text-primary group-hover:text-accent transition-colors truncate">
            {title || 'Untitled'}
          </h3>
          <p className="text-sm text-text-secondary mt-1 line-clamp-2">
            {truncate(content, 100)}
          </p>
        </div>
        {language && (
          <span className="px-2 py-1 text-xs font-medium rounded bg-accent/10 text-accent whitespace-nowrap">
            {language}
          </span>
        )}
      </div>
      <div className="flex items-center gap-4 mt-4 text-xs text-text-secondary">
        <span className="font-mono">/{slug}</span>
        <span>{formatRelativeDate(created_at)}</span>
      </div>
    </Link>
  )
}