'use client'

import { useEffect, useState } from 'react'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { Button } from '@/components/ui/Button'
import { CodeBlock } from '@/components/CodeBlock'
import { useToast } from '@/components/ui/Toast'
import { formatDate, isExpired } from '@/lib/utils'

interface Paste {
  id: string
  slug: string
  title: string
  description: string | null
  content: string
  language: string | null
  created_at: string
  expires_at: string | null
}

export default function ViewPastePage() {
  const params = useParams()
  const slug = params.slug as string
  const { addToast } = useToast()
  const [paste, setPaste] = useState<Paste | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    async function fetchPaste() {
      try {
        const response = await fetch(`/api/pastes/${slug}`)
        if (!response.ok) {
          if (response.status === 404) {
            notFound()
          }
          throw new Error('Failed to fetch paste')
        }
        const data = await response.json()
        setPaste(data)
      } catch (error) {
        addToast('Failed to load paste', 'error')
      } finally {
        setLoading(false)
      }
    }
    fetchPaste()
  }, [slug, addToast])

  const handleCopy = async () => {
    if (!paste) return
    try {
      await navigator.clipboard.writeText(paste.content)
      setCopied(true)
      addToast('Copied to clipboard!', 'success')
      setTimeout(() => setCopied(false), 2000)
    } catch {
      addToast('Failed to copy', 'error')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!paste) {
    notFound()
  }

  const expired = isExpired(paste.expires_at)

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-background"
                >
                  <path d="M16 18 22 12 16 6" />
                  <path d="M8 6 2 12 8 18" />
                </svg>
              </div>
              <span className="font-mono font-bold text-xl">Pastebin</span>
            </Link>
            <div className="flex items-center gap-3">
              <Link href="/new">
                <Button variant="primary" size="sm">
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                  New Paste
                </Button>
              </Link>
              <Link href={`/${slug}/raw`}>
                <Button variant="secondary" size="sm">
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  Raw
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-6 py-8">
        <div className="mb-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="font-mono text-2xl font-bold mb-2">
                {paste.title || 'Untitled'}
              </h1>
              {paste.description && (
                <p className="text-text-secondary mb-4">{paste.description}</p>
              )}
              <div className="flex items-center gap-4 text-sm text-text-secondary">
                <span className="font-mono">/{paste.slug}</span>
                <span>{formatDate(paste.created_at)}</span>
                {paste.language && (
                  <span className="px-2 py-1 text-xs font-medium rounded bg-accent/10 text-accent">
                    {paste.language}
                  </span>
                )}
              </div>
            </div>
            {!expired && (
              <Button
                variant="secondary"
                size="sm"
                onClick={handleCopy}
              >
                {copied ? (
                  <>
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    Copied!
                  </>
                ) : (
                  <>
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                    </svg>
                    Copy
                  </>
                )}
              </Button>
            )}
          </div>
        </div>

        <div className="relative">
          {expired ? (
            <div className="bg-surface border border-border rounded-lg p-12 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-danger/10 rounded-full mb-4">
                <svg
                  width="32"
                  height="32"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-danger"
                >
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12 6 12 12 16 14" />
                </svg>
              </div>
              <h2 className="font-mono font-semibold text-xl mb-2">This paste has expired</h2>
              <p className="text-text-secondary">The content is no longer available for viewing.</p>
            </div>
          ) : (
            <CodeBlock code={paste.content} language={paste.language} />
          )}
        </div>

        <div className="mt-8 pt-8 border-t border-border">
          <div className="flex items-center gap-4 text-sm text-text-secondary">
            <Link href="/" className="hover:text-accent transition-colors flex items-center gap-1">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m12 19-7-7 7-7" />
                <path d="M19 12H5" />
              </svg>
              Back to home
            </Link>
            <Link href="/new" className="hover:text-accent transition-colors flex items-center gap-1">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 5v14M5 12h14" />
              </svg>
              Create new paste
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}