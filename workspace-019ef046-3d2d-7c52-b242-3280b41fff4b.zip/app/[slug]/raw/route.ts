import { NextRequest, NextResponse } from 'next/server'
import { getPasteBySlug } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const slug = params.slug
  const paste = getPasteBySlug(slug)

  if (!paste) {
    return new NextResponse('Paste not found', { status: 404 })
  }

  return new NextResponse(paste.content, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
    },
  })
}