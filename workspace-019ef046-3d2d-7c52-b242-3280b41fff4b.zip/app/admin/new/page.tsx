'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Input, Textarea, Select } from '@/components/ui/Input'
import { useToast } from '@/components/ui/Toast'
import { LANGUAGES } from '@/lib/utils'

export default function AdminNewPastePage() {
  const router = useRouter()
  const { addToast } = useToast()
  const [loading, setLoading] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    content: '',
    language: 'plaintext',
    expires_at: '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    checkAuth()
  }, [])

  async function checkAuth() {
    try {
      const response = await fetch('/api/admin/check')
      if (response.ok) {
        setIsAuthenticated(true)
      } else {
        setIsAuthenticated(false)
        router.push('/admin')
      }
    } catch {
      setIsAuthenticated(false)
      router.push('/admin')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.content.trim()) {
      setErrors({ content: 'Content is required' })
      return
    }

    setLoading(true)
    setErrors({})

    try {
      const response = await fetch('/api/pastes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title || 'Untitled',
          description: formData.description || null,
          content: formData.content,
          language: formData.language === 'plaintext' ? null : formData.language,
          expires_at: formData.expires_at || null,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || 'Failed to create paste')
      }

      const paste = await response.json()
      addToast('Paste created successfully!', 'success')
      router.push('/admin')
    } catch (error) {
      addToast(error instanceof Error ? error.message : 'Failed to create paste', 'error')
      setLoading(false)
    }
  }

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border">
        <div className="max-w-3xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/admin" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-background"
                >
                  <path d="M16 18 22 12 16 6" />
                  <path d="M8 6 2 12 8 18" />
                </svg>
              </div>
              <span className="font-mono font-bold text-xl">Pastebin</span>
            </Link>
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m12 19-7-7 7-7" />
                  <path d="M19 12H5" />
                </svg>
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-3xl mx-auto w-full px-6 py-12">
        <div className="mb-8">
          <h1 className="font-mono text-3xl font-bold mb-2">Create New Paste</h1>
          <p className="text-text-secondary">Create a new paste from the admin panel</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Input
              label="Title"
              placeholder="Untitled"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
            <Select
              label="Language"
              options={LANGUAGES.map((l) => ({ value: l.value, label: l.label }))}
              value={formData.language}
              onChange={(e) => setFormData({ ...formData, language: e.target.value })}
            />
          </div>

          <Input
            label="Description (optional)"
            placeholder="A brief description of your paste"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          />

          <div className="space-y-2">
            <label className="block text-sm font-medium text-text-secondary">
              Content <span className="text-danger">*</span>
            </label>
            <textarea
              placeholder="Paste your code here..."
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              className={`w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary placeholder:text-text-secondary focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/20 transition-colors resize-none font-mono h-64 ${
                errors.content ? 'border-danger' : ''
              }`}
            />
            {errors.content && (
              <p className="text-sm text-danger">{errors.content}</p>
            )}
          </div>

          <Input
            label="Expires At (optional)"
            type="datetime-local"
            value={formData.expires_at}
            onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
          />

          <div className="flex items-center gap-4 pt-4">
            <Button type="submit" loading={loading}>
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                <polyline points="17 21 17 13 7 13 7 21" />
                <polyline points="7 3 7 8 15 8" />
              </svg>
              Create Paste
            </Button>
            <Link href="/admin">
              <Button type="button" variant="secondary">
                Cancel
              </Button>
            </Link>
          </div>
        </form>
      </main>
    </div>
  )
}