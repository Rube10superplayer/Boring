'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Input, Textarea, Select } from '@/components/ui/Input'
import { Modal } from '@/components/ui/Modal'
import { useToast } from '@/components/ui/Toast'
import { formatDate, formatRelativeDate, LANGUAGES } from '@/lib/utils'

interface Paste {
  id: string
  slug: string
  title: string
  description: string | null
  content: string
  language: string | null
  created_at: string
  expires_at: string | null
}

export default function AdminPage() {
  const router = useRouter()
  const { addToast } = useToast()
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [loginLoading, setLoginLoading] = useState(false)
  
  const [pastes, setPastes] = useState<Paste[]>([])
  const [loading, setLoading] = useState(false)
  
  const [editingPaste, setEditingPaste] = useState<Paste | null>(null)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  useEffect(() => {
    checkAuth()
  }, [])

  async function checkAuth() {
    try {
      const response = await fetch('/api/admin/check')
      if (response.ok) {
        setIsAuthenticated(true)
        fetchPastes()
      } else {
        setIsAuthenticated(false)
      }
    } catch {
      setIsAuthenticated(false)
    }
  }

  async function fetchPastes() {
    setLoading(true)
    try {
      const response = await fetch('/api/pastes')
      if (response.ok) {
        const data = await response.json()
        setPastes(data)
      }
    } catch {
      addToast('Failed to fetch pastes', 'error')
    } finally {
      setLoading(false)
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoginError('')
    setLoginLoading(true)

    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })

      if (response.ok) {
        setIsAuthenticated(true)
        fetchPastes()
      } else {
        setLoginError('Invalid password')
      }
    } catch {
      setLoginError('Login failed')
    } finally {
      setLoginLoading(false)
    }
  }

  async function handleLogout() {
    try {
      await fetch('/api/admin/logout', { method: 'POST' })
      setIsAuthenticated(false)
      setPastes([])
    } catch {
      addToast('Logout failed', 'error')
    }
  }

  async function handleDelete(id: string) {
    try {
      const response = await fetch(`/api/pastes/${id}`, { method: 'DELETE' })
      if (response.ok) {
        setPastes(pastes.filter((p) => p.id !== id))
        addToast('Paste deleted', 'success')
      } else {
        addToast('Failed to delete paste', 'error')
      }
    } catch {
      addToast('Failed to delete paste', 'error')
    }
    setDeleteConfirm(null)
  }

  async function handleEditSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!editingPaste) return

    const formData = new FormData(e.target as HTMLFormElement)
    const updatedData = {
      title: formData.get('title') as string,
      description: formData.get('description') as string || null,
      content: formData.get('content') as string,
      language: formData.get('language') as string || null,
      expires_at: formData.get('expires_at') as string || null,
    }

    try {
      const response = await fetch(`/api/pastes/${editingPaste.slug}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData),
      })

      if (response.ok) {
        const updated = await response.json()
        setPastes(pastes.map((p) => (p.id === updated.id ? updated : p)))
        setEditingPaste(null)
        addToast('Paste updated', 'success')
      } else {
        addToast('Failed to update paste', 'error')
      }
    } catch {
      addToast('Failed to update paste', 'error')
    }
  }

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col">
        <header className="border-b border-border">
          <div className="max-w-md mx-auto px-6 py-6">
            <Link href="/" className="flex items-center gap-3 justify-center">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-background"
                >
                  <path d="M16 18 22 12 16 6" />
                  <path d="M8 6 2 12 8 18" />
                </svg>
              </div>
              <span className="font-mono font-bold text-xl">Admin Panel</span>
            </Link>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="card text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/10 rounded-full mb-6">
                <svg
                  width="32"
                  height="32"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-accent"
                >
                  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
              </div>
              <h1 className="font-mono text-2xl font-bold mb-2">Admin Login</h1>
              <p className="text-text-secondary mb-8">Enter the admin secret to access the dashboard</p>
              
              <form onSubmit={handleLogin} className="space-y-4">
                <Input
                  type="password"
                  placeholder="Enter admin secret"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  error={loginError}
                  autoFocus
                />
                <Button type="submit" loading={loginLoading} className="w-full">
                  Sign In
                </Button>
              </form>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-background"
                  >
                    <path d="M16 18 22 12 16 6" />
                    <path d="M8 6 2 12 8 18" />
                  </svg>
                </div>
                <span className="font-mono font-bold text-xl">Pastebin</span>
              </Link>
              <span className="px-3 py-1 text-xs font-medium rounded bg-accent/10 text-accent">
                Admin
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/admin/new">
                <Button variant="primary" size="sm">
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                  New Paste
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" x2="9" y1="12" y2="12" />
                </svg>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl mx-auto w-full px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-mono text-2xl font-bold mb-1">Dashboard</h1>
            <p className="text-text-secondary">Manage all your pastes</p>
          </div>
          <div className="text-sm text-text-secondary">
            {pastes.length} paste{pastes.length !== 1 ? 's' : ''}
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full" />
          </div>
        ) : pastes.length === 0 ? (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-surface rounded-full mb-6">
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-text-secondary"
              >
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
            </div>
            <h3 className="font-mono font-semibold text-lg mb-2">No pastes yet</h3>
            <p className="text-text-secondary mb-6">Create your first paste to get started</p>
            <Link href="/new">
              <Button variant="primary">Create Paste</Button>
            </Link>
          </div>
        ) : (
          <div className="bg-surface border border-border rounded-xl overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Title</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Slug</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Language</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Created</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-text-secondary">Actions</th>
                </tr>
              </thead>
              <tbody>
                {pastes.map((paste, index) => (
                  <tr
                    key={paste.id}
                    className={`border-b border-border last:border-b-0 ${
                      index % 2 === 0 ? 'bg-surface' : 'bg-background/30'
                    }`}
                  >
                    <td className="px-6 py-4">
                      <div className="font-medium truncate max-w-[200px]">
                        {paste.title || 'Untitled'}
                      </div>
                      {paste.description && (
                        <div className="text-sm text-text-secondary truncate max-w-[200px]">
                          {paste.description}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 font-mono text-sm">
                      <Link href={`/${paste.slug}`} className="text-accent hover:underline">
                        /{paste.slug}
                      </Link>
                    </td>
                    <td className="px-6 py-4">
                      {paste.language ? (
                        <span className="px-2 py-1 text-xs font-medium rounded bg-accent/10 text-accent">
                          {paste.language}
                        </span>
                      ) : (
                        <span className="text-text-secondary text-sm">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-text-secondary">
                      <div title={formatDate(paste.created_at)}>
                        {formatRelativeDate(paste.created_at)}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingPaste(paste)}
                        >
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                            <path d="m15 5 4 4" />
                          </svg>
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeleteConfirm(paste.id)}
                          className="text-danger hover:bg-danger/10"
                        >
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                          </svg>
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {/* Edit Modal */}
      <Modal
        isOpen={!!editingPaste}
        onClose={() => setEditingPaste(null)}
        title="Edit Paste"
      >
        {editingPaste && (
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <Input
              name="title"
              label="Title"
              defaultValue={editingPaste.title}
              placeholder="Untitled"
            />
            <Input
              name="description"
              label="Description"
              defaultValue={editingPaste.description || ''}
              placeholder="Optional description"
            />
            <Select
              name="language"
              label="Language"
              options={LANGUAGES.map((l) => ({ value: l.value, label: l.label }))}
              defaultValue={editingPaste.language || 'plaintext'}
            />
            <div className="space-y-2">
              <label className="block text-sm font-medium text-text-secondary">Content</label>
              <textarea
                name="content"
                defaultValue={editingPaste.content}
                className="w-full px-4 py-3 bg-background border border-border rounded-lg text-text-primary font-mono resize-none h-48"
                required
              />
            </div>
            <Input
              name="expires_at"
              label="Expires At"
              type="datetime-local"
              defaultValue={editingPaste.expires_at ? editingPaste.expires_at.slice(0, 16) : ''}
            />
            <div className="flex items-center gap-3 pt-4">
              <Button type="submit">
                Save Changes
              </Button>
              <Button type="button" variant="secondary" onClick={() => setEditingPaste(null)}>
                Cancel
              </Button>
            </div>
          </form>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        title="Delete Paste"
      >
        <p className="text-text-secondary mb-6">
          Are you sure you want to delete this paste? This action cannot be undone.
        </p>
        <div className="flex items-center gap-3">
          <Button
            variant="danger"
            onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
          >
            Delete
          </Button>
          <Button variant="secondary" onClick={() => setDeleteConfirm(null)}>
            Cancel
          </Button>
        </div>
      </Modal>
    </div>
  )
}