import { NextRequest, NextResponse } from 'next/server'
import { getAllPastes, createPaste, getRecentPastes, isSlugTaken } from '@/lib/db'
import { generateSlug } from '@/lib/utils'
import { nanoid } from 'nanoid'
import { getSession } from '@/lib/auth'

export async function GET(request: NextRequest) {
  const session = await getSession()
  
  if (!session?.authenticated) {
    const pastes = getRecentPastes(10)
    return NextResponse.json(pastes)
  }
  
  const pastes = getAllPastes()
  return NextResponse.json(pastes)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, content, language, expires_at } = body

    if (!content || !content.trim()) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      )
    }

    let slug = generateSlug()
    while (isSlugTaken(slug)) {
      slug = generateSlug()
    }

    const id = nanoid()

    const paste = createPaste({
      id,
      slug,
      title: title?.trim() || 'Untitled',
      description: description || null,
      content: content.trim(),
      language: language || null,
      expires_at: expires_at || null,
    })

    return NextResponse.json(paste, { status: 201 })
  } catch (error) {
    console.error('Error creating paste:', error)
    return NextResponse.json(
      { error: 'Failed to create paste' },
      { status: 500 }
    )
  }
}