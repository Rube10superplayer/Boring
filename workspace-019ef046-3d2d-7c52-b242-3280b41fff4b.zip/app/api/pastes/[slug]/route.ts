import { NextRequest, NextResponse } from 'next/server'
import { getPasteBySlug, getPasteById, updatePaste, deletePaste } from '@/lib/db'
import { getSession } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const paste = getPasteBySlug(params.slug)

  if (!paste) {
    return NextResponse.json(
      { error: 'Paste not found' },
      { status: 404 }
    )
  }

  return NextResponse.json(paste)
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const session = await getSession()
  
  if (!session?.authenticated) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }

  try {
    const paste = getPasteBySlug(params.slug)
    
    if (!paste) {
      return NextResponse.json(
        { error: 'Paste not found' },
        { status: 404 }
      )
    }

    const body = await request.json()
    const { title, description, content, language, expires_at } = body

    const updated = updatePaste(paste.id, {
      title,
      description,
      content,
      language,
      expires_at,
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error('Error updating paste:', error)
    return NextResponse.json(
      { error: 'Failed to update paste' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const session = await getSession()
  
  if (!session?.authenticated) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }

  const paste = getPasteBySlug(params.slug)
  
  if (!paste) {
    return NextResponse.json(
      { error: 'Paste not found' },
      { status: 404 }
    )
  }

  const deleted = deletePaste(paste.id)

  if (!deleted) {
    return NextResponse.json(
      { error: 'Failed to delete paste' },
      { status: 500 }
    )
  }

  return NextResponse.json({ success: true })
}