import Link from 'next/link'
import { getRecentPastes } from '@/lib/db'
import { PasteCard } from '@/components/PasteCard'
import { Button } from '@/components/ui/Button'

export const dynamic = 'force-dynamic'

export default function HomePage() {
  const recentPastes = getRecentPastes(12)

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-background"
              >
                <path d="M16 18 22 12 16 6" />
                <path d="M8 6 2 12 8 18" />
              </svg>
            </div>
            <span className="font-mono font-bold text-xl">Pastebin</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/new">
              <Button variant="primary" size="sm">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 5v14M5 12h14" />
                </svg>
                New Paste
              </Button>
            </Link>
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                Admin
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-6 py-12">
        <section className="text-center mb-12">
          <h1 className="font-mono text-4xl font-bold mb-4">
            Share code <span className="text-accent">instantly</span>
          </h1>
          <p className="text-text-secondary text-lg max-w-md mx-auto">
            Create pastes with syntax highlighting, share them via short URLs, and manage everything from a simple admin panel.
          </p>
          <div className="flex items-center justify-center gap-4 mt-8">
            <Link href="/new">
              <Button variant="primary" size="lg">
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 5v14M5 12h14" />
                </svg>
                Create New Paste
              </Button>
            </Link>
          </div>
        </section>

        {recentPastes.length > 0 ? (
          <section>
            <h2 className="font-mono text-lg font-semibold mb-6 flex items-center gap-2">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              Recent Pastes
            </h2>
            <div className="grid gap-4 md:grid-cols-2">
              {recentPastes.map((paste) => (
                <PasteCard
                  key={paste.id}
                  slug={paste.slug}
                  title={paste.title}
                  language={paste.language}
                  created_at={paste.created_at}
                  content={paste.content}
                />
              ))}
            </div>
          </section>
        ) : (
          <section className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-surface rounded-full mb-6">
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-text-secondary"
              >
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
            </div>
            <h3 className="font-mono font-semibold text-lg mb-2">No pastes yet</h3>
            <p className="text-text-secondary">Be the first to create a paste!</p>
          </section>
        )}
      </main>

      <footer className="border-t border-border mt-auto">
        <div className="max-w-4xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between text-sm text-text-secondary">
            <span>Built with Next.js + Tailwind CSS</span>
            <span className="font-mono">Self-hosted</span>
          </div>
        </div>
      </footer>
    </div>
  )
}