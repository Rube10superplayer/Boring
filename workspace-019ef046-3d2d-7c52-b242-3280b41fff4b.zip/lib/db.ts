import Database from 'better-sqlite3'
import path from 'path'
import fs from 'fs'

export interface Paste {
  id: string
  slug: string
  title: string
  description: string | null
  content: string
  language: string | null
  created_at: string
  expires_at: string | null
}

const dbPath = process.env.DATABASE_URL || './data/pastebin.db'
const dbDir = path.dirname(dbPath)

if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true })
}

const db = new Database(dbPath)

db.exec(`
  CREATE TABLE IF NOT EXISTS pastes (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    title TEXT DEFAULT 'Untitled',
    description TEXT,
    content TEXT NOT NULL,
    language TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
  )
`)

export function createPaste(paste: Omit<Paste, 'created_at'>): Paste {
  const stmt = db.prepare(`
    INSERT INTO pastes (id, slug, title, description, content, language, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `)
  stmt.run(paste.id, paste.slug, paste.title, paste.description, paste.content, paste.language, paste.expires_at)
  return getPasteBySlug(paste.slug)!
}

export function getPasteBySlug(slug: string): Paste | null {
  const stmt = db.prepare('SELECT * FROM pastes WHERE slug = ?')
  const paste = stmt.get(slug) as Paste | undefined
  return paste || null
}

export function getPasteById(id: string): Paste | null {
  const stmt = db.prepare('SELECT * FROM pastes WHERE id = ?')
  const paste = stmt.get(id) as Paste | undefined
  return paste || null
}

export function getAllPastes(): Paste[] {
  const stmt = db.prepare('SELECT * FROM pastes ORDER BY created_at DESC')
  return stmt.all() as Paste[]
}

export function updatePaste(id: string, updates: Partial<Omit<Paste, 'id' | 'created_at'>>): Paste | null {
  const current = getPasteById(id)
  if (!current) return null

  const stmt = db.prepare(`
    UPDATE pastes SET
      title = ?,
      description = ?,
      content = ?,
      language = ?,
      expires_at = ?
    WHERE id = ?
  `)
  stmt.run(
    updates.title ?? current.title,
    updates.description ?? current.description,
    updates.content ?? current.content,
    updates.language ?? current.language,
    updates.expires_at ?? current.expires_at,
    id
  )
  return getPasteById(id)
}

export function deletePaste(id: string): boolean {
  const stmt = db.prepare('DELETE FROM pastes WHERE id = ?')
  const result = stmt.run(id)
  return result.changes > 0
}

export function getRecentPastes(limit: number = 10): Paste[] {
  const stmt = db.prepare('SELECT * FROM pastes ORDER BY created_at DESC LIMIT ?')
  return stmt.all(limit) as Paste[]
}

export function isSlugTaken(slug: string): boolean {
  const stmt = db.prepare('SELECT 1 FROM pastes WHERE slug = ?')
  return stmt.get(slug) !== undefined
}