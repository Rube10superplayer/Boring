# Pastebin Clone

A sleek, self-hosted pastebin built with Next.js 14, Tailwind CSS, and SQLite.

## Features

- **Create pastes** with title, description, code content, and language
- **Syntax highlighting** powered by highlight.js
- **Unique short URLs** for each paste (8-character nanoid slugs)
- **Expiry support** - pastes can auto-expire
- **Admin panel** - password-protected management dashboard
- **Raw view** - access plain text at `/[slug]/raw`
- **Dark theme** - developer-focused terminal aesthetic

## Tech Stack

- **Next.js 14** - App Router with API routes
- **Tailwind CSS** - Utility-first styling
- **SQLite** - Persistent database (better-sqlite3)
- **highlight.js** - Client-side syntax highlighting
- **nanoid** - URL-safe slug generation
- **jose** - JWT-based admin authentication

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

Create a `.env.local` file in the project root:

```env
# Admin password (required)
ADMIN_SECRET=your-secret-password

# Database path (optional, defaults to ./data/pastebin.db)
DATABASE_URL=./data/pastebin.db
```

### 3. Run the development server

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

## Routes

| Route | Description |
|-------|-------------|
| `/` | Homepage with recent pastes |
| `/new` | Create a new paste |
| `/[slug]` | View a paste with syntax highlighting |
| `/[slug]/raw` | Raw text view |
| `/admin` | Admin dashboard (login required) |

## Deployment

The app is deploy-ready for Vercel or any Node.js host.

For serverless platforms, consider using a managed database like Supabase or Turso instead of SQLite.

### Vercel Deployment

1. Push to GitHub
2. Connect to Vercel
3. Add environment variables (`ADMIN_SECRET`, `DATABASE_URL`)
4. Deploy

## Project Structure

```
├── app/
│   ├── api/
│   │   ├── admin/
│   │   │   ├── check/route.ts    # Auth check
│   │   │   ├── login/route.ts    # Admin login
│   │   │   └── logout/route.ts   # Admin logout
│   │   └── pastes/
│   │       ├── route.ts          # List/create pastes
│   │       └── [slug]/route.ts   # Get/update/delete paste
│   ├── [slug]/
│   │   ├── page.tsx              # View paste
│   │   └── raw/route.ts          # Raw text endpoint
│   ├── admin/
│   │   ├── page.tsx              # Admin dashboard
│   │   └── new/page.tsx          # Create paste (admin)
│   ├── new/page.tsx              # Create paste (public)
│   ├── layout.tsx
│   ├── page.tsx                  # Homepage
│   ├── globals.css
│   └── not-found.tsx
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Modal.tsx
│   │   └── Toast.tsx
│   ├── CodeBlock.tsx
│   └── PasteCard.tsx
├── lib/
│   ├── auth.ts                   # JWT authentication
│   ├── db.ts                     # Database operations
│   └── utils.ts                  # Helpers and constants
├── data/                         # SQLite database directory
├── SPEC.md                       # Design specification
└── package.json
```

## Database Schema

```sql
CREATE TABLE pastes (
  id TEXT PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT DEFAULT 'Untitled',
  description TEXT,
  content TEXT NOT NULL,
  language TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME
);
```

## Security

- Admin panel protected by JWT cookie (24-hour expiry)
- ADMIN_SECRET validated server-side
- No hardcoded credentials
- HttpOnly, secure cookies in production